soap4me
=======

Kodi (xbmc) plugin for soap4.me

Current version 1.0.15
