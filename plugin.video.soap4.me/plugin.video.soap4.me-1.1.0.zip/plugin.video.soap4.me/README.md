soap4me
=======

Kodi (xbmc) plugin for soap4.me

Current version 1.1.0

Last version with support python2 1.0.20
